in work_fine folder the program run finely where i wrote each character deeply and noise size is big

in word_bad folder the program failed to detect all characters and it detect noise also where character depth is light and has extra noise like keyboard key(which it detected as a character).
